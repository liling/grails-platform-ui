modules = {
    // Resources for your custom UI Set
    'ui.@artifact.name@' {

    }
}